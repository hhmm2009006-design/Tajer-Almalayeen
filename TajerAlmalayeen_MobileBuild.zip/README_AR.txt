تاجر الملايين — مشروع أندرويد أولي

هذا مشروع Android Studio يحتوي لعبة تجريبية تعمل محلياً داخل WebView.
ليس ملف APK جاهزاً بعد.

طريقة بناء APK:
1) افتح المشروع في Android Studio على كمبيوتر.
2) انتظر مزامنة Gradle وتنزيل مكونات Android المطلوبة.
3) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
4) ستجد APK في app/build/outputs/apk/debug/app-debug.apk

ملاحظات:
- العملة والأرباح داخل اللعبة افتراضية للتجربة فقط.
- لا يوجد تحويل أموال أو ربط فعلي ببطاقة Mastercard.
- لا تضع أرقام البطاقة أو CVV أو PIN في التطبيق.
